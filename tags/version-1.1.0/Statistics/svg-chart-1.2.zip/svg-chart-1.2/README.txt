--- Still to do ---

-  Finish porting all of the chart objects from the Ruby libraries.
-  Factor out default stylesheets so that individual properties may be overridden without copying the entire stylesheet into another app.
-  Implement javascript-based animation (See JellyGraph for a Silverlight example of what simple animation can do for a charting library).
-  Implement namespace-based packages (see http://peak.telecommunity.com/DevCenter/setuptools#namespace-packages)... so that the package is svg.chart.Graph, etc.
-  Convert to using element-tree instead of whatever I'm using