Ballistic Viewer v1.0.4 - January 29th 2007
===========================================

Note: This version corrects a bug with textures extensions in uppercase

Read collada files (.dae)

Supported:
---------
- library_images
- library_materials
- library_effects: diffuse-color or diffuse-texture
- triangles: vertices, normals, texture coordinates
- library_nodes
- library_visual_scenes
- matrix

Tested successfully with Google Earth models available on the Google 3D Warehouse. Support for collada files from other origins is foreseen in a near future. 

The export from Blender gives already good results if you export triangles and baked matrices. There remain problems about normals and textures which are to ne investigated. 

Textures have been tested with .dae models created with Google SketchUp 2.9.5 and 3.0.5. You may experience problems with models containing duplicates of meshes (instances), using SU 2.9.5, like the US Capitol. The texture of the duplicate is dark. Google has solved this in SU 3.0.5. 

Only .jpg and .png are supported for the moment.

If you don't see the model, it's probably too small, so use the zoom command. Collada Viewpoint support is also foreseen in the near future.

To get the .dae file: open the model in Google Sketch Up, export to Google Earth, then unzip the .kmz. You will get a .kml file which is used to position the model on earth, the geometry (.dae) will be available in a subdirectoty called models. Textures are stored in a subdirectory called images.

Note that Ballistic 3D acts totally independently from Google Inc.

Please report bugs and comments to support@ballistic3d.com




