This model is a simple Dice (a textured cube).

It uses polylist for the cube mesh.

The model has been stripped of all <extra> tags and should be COLLADA 1.4.1 compliant.

For additional information post messages on www.collada.org or mail collada@collada.org

These model is Copyright 2008 Sony Computer Entertainment Inc.
Licensed under the Creative Commons Attribution Noncommercial Share Alike license.
See license file or www.creativecommons.org for details.
